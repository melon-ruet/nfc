
*** Development Environment ***

For NFC programming on Android, first you need to create an Android development environment.

The most suitable way to do that is to install Android Development Tools (ADT) Bundle. ADT is available on Windows, MAC, and Linux operating systems. 

Moreover, in order to test NFC reader/writer mode applications, you need to have an NFC-enabled mobile phone and an NFC tag. 

In order to test NFC peer-to-peer mode applications, you need to have two NFC-enabled mobile phones.

In order to test card emulation mode applications, you need to have an additional Java Card that can be plugged-in to the mobile phone.


*** Description of the Content ***

1. Hello World Project is the first Android project of this book. It consists of only one Java class, HelloWorld. This file includes the code for this class, which also is the main activity of the project, and also includes other resources (layouts, values, menu etc.) for an Android project. You can find instructions related with this first project in Chapter 4.
 
2. ImageDisplayerwithMenu project includes the required codes and resources for creating menu items. You can find instructions related with using menu items in Chapter 4.


3. MileAndMeterConverter is the second project of this book in Chapter 4. This file includes the required codes, resources (values, layouts etc.) for building a miles-to-kilometers converter.


3. MileAndMeterConverter_Relative is the third project of this book in Chapter 4. In this project, MileAndMeterConverter is modified to create a relative layout. This file includes the required codes and resources (values, relative layout etc.)  for building a miles-to-kilometers converter.


4. MileAndMeterConverter_Grid is the forth project of this book in Chapter 4. In this project, MileAndMeterConverter is modified to create a grid layout. This file includes the required codes and resources (values, grid layout etc.)  for building a miles-to-kilometers converter.

5. MultipleActivities file includes the codes and resources for creating an application that consists of multiple activities (Mile & Meter Converter, Celsius & Fahrenheit Converter, and Foot & Yard Converter). You can find instructions related with using menu items in Chapter 4.


6. NFCPosterTagWriter includes the Android manifest file, resources and source files for writing a URL, Phone Number, SMS Message, geolocation, E-mail  to an NFC tag. The use case description is given with the codes in Chapter 6.


7. NFCShoppingTagWriter includes the Android manifest file, resources and source files for NFC shopping application. The use case description is given with the codes in Chapter 6.


8. NFCStudentTrackingTagWriter includes Android manifest file, resources and source files for student transportation tracking application. The use case description is given with the codes in Chapter 6.


9. PeertoPeer1 includes Android manifest file, activity, resources and source files for a peer to peer application with setNdefPushMessageCallback() method. You can find instructions related with this application in Chapter 7.


10. PeertoPeer2 includes Android manifest file, activity, resources and source files for a peer to  peer application with setNdefPushMessage() method. You can find instructions related with this application in Chapter 7.


11. PeertoPeer3 includes Android manifest file, activity, resources and source files for a peer to  peer application with enableForegroundNdefPush() method. You can find instructions related with this application in Chapter 7.


12. PeertoPeer4 includes Android manifest file, activity, resources and source files for a peer to peer contact sharing application. You can find instructions related with this application in Chapter 7.


13. NFCChat project includes the Android manifest file, resources and source files for NFC chatting (one-to-one instant messaging) application. The use case description is given with the codes in Chapter 8.


14. NFCGuessNumber project includes the Android manifest file, resources and source files for NFC guess number game application. The use case description is given with the codes in Chapter 8.


15. NFCPanicBomb project includes the Android manifest file, resources and source files for NFC panic bomb game application. The use case description is given with the codes in Chapter 8.

