package com.nfclab.converter;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MileAndMeterConverter extends Activity {
	
	private RadioButton meterToMileButton;
	private RadioButton mileToMeterButton;
	private EditText input;
	private TextView output;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        meterToMileButton = (RadioButton) findViewById(R.id.radio0);
		mileToMeterButton = (RadioButton) findViewById(R.id.radio1);
		input = (EditText) findViewById(R.id.inputField);
        output = (TextView) findViewById(R.id.outputText);
    }
    
    public void onClickHandler(View view) {
		if(view.getId() == R.id.convertButton){
			if (input.getText().length() == 0) {
				output.setText("Please enter a number");
				return;
			}
			float inputValue = Float.parseFloat(input.getText().toString());
			if (meterToMileButton.isChecked())
				output.setText(inputValue+" kilometers equal to " + 
						String.format("%.2f", meterToMile(inputValue)) + " miles");
			else if(mileToMeterButton.isChecked()) 
				output.setText(inputValue+" miles equal to " + 
						String.format("%.2f", mileToMeter(inputValue)) + " kilometers");
		}
  
	}

	// Convert to mile
	private float meterToMile(float kilometer) {
		return (float) (kilometer/1.609);
	}

	// Convert to meter
	private float mileToMeter(float mile) {
		return (float) (mile*1.609);
	}
	
}