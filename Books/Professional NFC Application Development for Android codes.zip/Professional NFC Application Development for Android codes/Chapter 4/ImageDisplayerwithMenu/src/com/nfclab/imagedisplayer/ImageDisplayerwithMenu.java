package com.nfclab.imagedisplayer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

public class ImageDisplayerwithMenu extends Activity {

    private ImageView image;
    private TextView header;
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        image = (ImageView)findViewById(R.id.NFCImage);
        header = (TextView) findViewById(R.id.myHeaderText);
    }
	
   public void changeImage(int id) {
    
    	if(id==R.id.ceMode){
    			image.setImageResource(R.drawable.cemode);
            	header.setText("Displaying Card Emulation Mode Image");
    	}else if(id==R.id.p2pMode){
    			image.setImageResource(R.drawable.p2pmode);
            	header.setText("Displaying Peer to Peer Mode Image");
            }
   }
   
   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater menuInflater = getMenuInflater();
		menuInflater.inflate(R.menu.menu, menu);
	   	return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
	changeImage(item.getItemId());
   	return true;
	}
}