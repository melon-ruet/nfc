package com.nfclab.multipleactivities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class FootToYard extends Activity {
	    
		private EditText input;
		private TextView output;
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.foottoyard);
	        input = (EditText) findViewById(R.id.inputField);
	        output = (TextView) findViewById(R.id.outputText);
	    }
	    
	    public void onClickHandler(View view) {
	    	
	    	if(view.getId()==R.id.cancelButton){
				AlertDialog.Builder alert = new AlertDialog.Builder(this);
				alert.setTitle("Returning to Main Menu");
				alert.setMessage("Are you sure?");
				alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				   public void onClick(DialogInterface dialog, int whichButton) {
					   FootToYard.this.finish();
				   }
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					   public void onClick(DialogInterface dialog, int whichButton) {
						  dialog.cancel();
					   }
					});
				alert.show();
				
			}
	    	else if (input.getText().length() == 0) {
	    		output.setText("");
				Toast.makeText(this, "Please enter a number",Toast.LENGTH_LONG).show();
			}
	    	else if(view.getId()==R.id.convertButton){
				RadioButton footToYardButton = (RadioButton) findViewById(R.id.radio0);
				RadioButton yardToFootButton = (RadioButton) findViewById(R.id.radio1);
				float inputValue = Float.parseFloat(input.getText().toString());
				if (footToYardButton.isChecked()) {
					output.setText(inputValue+" feet equal to "+String.format("%.2f", footToYard(inputValue))+" yards");
				} else if(yardToFootButton.isChecked()) {
					output.setText(inputValue+" yards equal to "+String.format("%.2f", yardToFoot(inputValue))+" feet");
				}
			}
			
	  
		}

		// Convert to foot
		private float footToYard(float foot) {
			return (float) (foot/3);
		}

		// Convert to yard
		private float yardToFoot(float yard) {
			return (float) (yard*3);
		}

	}