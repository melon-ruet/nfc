package com.nfclab.multipleactivities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class CelsiusToFahrenheit extends Activity {
	    
		private EditText input;
		private TextView output;
	    @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.celstofahr);
	        input = (EditText) findViewById(R.id.inputField);
	        output = (TextView) findViewById(R.id.outputText);
	    }
	    
	    public void onClickHandler(View view) {
	    	
	    	if(view.getId()==R.id.cancelButton){
				AlertDialog.Builder alert = new AlertDialog.Builder(this);
				alert.setTitle("Returning to Main Menu");
				alert.setMessage("Are you sure?");
				alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
				   public void onClick(DialogInterface dialog, int whichButton) {
					   CelsiusToFahrenheit.this.finish();
				   }
				});
				alert.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					   public void onClick(DialogInterface dialog, int whichButton) {
						  dialog.cancel();
					   }
					});
				alert.show();
				
			}
	    	else if (input.getText().length() == 0) {
	    		output.setText("");
				Toast.makeText(this, "Please enter a number",Toast.LENGTH_LONG).show();
			}
	    	else if(view.getId()==R.id.convertButton){
				RadioButton celsToFahrButton = (RadioButton) findViewById(R.id.radio0);
				RadioButton fahrToCelsButton = (RadioButton) findViewById(R.id.radio1);
				float inputValue = Float.parseFloat(input.getText().toString());
				if (celsToFahrButton.isChecked()) {
					output.setText(inputValue+" celsius equal to "+String.format("%.2f", celsToFahr(inputValue))+" fahrenheit");
				} else if(fahrToCelsButton.isChecked()) {
					output.setText(inputValue+" fahrenheit equal to "+String.format("%.2f", fahrToCels(inputValue))+" celsius");
				}
			}
			
	  
		}

		// Convert to fahrenheit
		private float celsToFahr(float celsius) {
			return (float) (celsius*1.8+32);
		}

		// Convert to celcius
		private float fahrToCels(float fahrenheit) {
			return (float) ((fahrenheit-32) / 1.8);
		}

	}