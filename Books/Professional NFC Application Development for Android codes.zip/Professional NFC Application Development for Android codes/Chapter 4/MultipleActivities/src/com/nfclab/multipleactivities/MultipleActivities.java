package com.nfclab.multipleactivities;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

public class MultipleActivities extends ListActivity implements OnItemClickListener {
    
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        //When you wish to deploy a list to the entire screen, you don't need to load any layout
        //no setContentView method
        
        //create list items from CONVERTERS array
        setListAdapter(new ArrayAdapter<String>(this, R.layout.main, CONVERTERS));

        //ListView gets the data to display via setListAdapter
        ListView myList = getListView();

        //You may turn on text filtering using the setTextFilterEnabled (true) method (not mandatory)
        //When the user begins typing, the list will be filtered
        myList.setTextFilterEnabled(true);
        
        // add onClick listener to the list
        myList.setOnItemClickListener(this);

    }

    // when a list item is selected, this method is called
	public void onItemClick(AdapterView<?> parent, View view, int position, long id) {	
		if(position==0){
			
			// create an Intent from MileToMeter class and start the Intent
			Intent intent = new Intent(this, MileToMeter.class);		
			startActivity(intent);
		}else if(position==1){
			
			// create an Intent from CelsiusToFahrenheit class and start the Intent
			Intent intent = new Intent(this, CelsiusToFahrenheit.class);
			startActivity(intent);
		}else if(position==2){
			// create an Intent from FootToYard class and start the Intent
			Intent intent = new Intent(this, FootToYard.class);
			startActivity(intent);
		}
	}
    
	// define a list of converters that the list will display
    static final String[] CONVERTERS = new String[] {
    	"Mile & Meter Converter",
    	"Celsius & Fahrenheit Converter",
    	"Foot & Yard Converter"
    };

    
}