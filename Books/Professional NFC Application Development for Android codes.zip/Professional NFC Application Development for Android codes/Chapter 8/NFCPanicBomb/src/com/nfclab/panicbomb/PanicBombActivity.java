package com.nfclab.panicbomb;

import java.util.Random;
import java.util.concurrent.TimeUnit;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.media.AudioManager;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class PanicBombActivity extends Activity {

	NfcAdapter mNfcAdapter;
	TextView messageText;
	ImageView bombIV;
	int elapsedSeconds = 0;
	int maxlifeTime = 60;
	int lifeTime = 0;
	long elapsedMillis=0;
	
	Chronometer chronometer;
	AudioManager audioManager;
	TextView questionText;
	EditText answerET;
	int number1, number2, answer;
	Context context;
	AnimationDrawable animation;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		context = (Context) this;
		
		bombIV = (ImageView)findViewById(R.id.bombIV);	    
		bombIV.setBackgroundResource(R.drawable.animation);
		animation = (AnimationDrawable) bombIV.getBackground(); 

		questionText = (TextView) findViewById(R.id.questionText);
		displayQuestion();
		answerET = (EditText) findViewById(R.id.answerET);
		
		lifeTime = random();
		messageText = (TextView) findViewById(R.id.messageText);

		mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
		if (mNfcAdapter == null) {
			messageText.setText("NFC apdater  is not available");
			finish();
			return;
		} 

		chronometer = (Chronometer) findViewById(R.id.chronometer);	
		
		chronometer.start();   
        		 
		chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
			public void onChronometerTick(Chronometer chronometer) {
				chronometer.refreshDrawableState();
				elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
				elapsedSeconds = (int) TimeUnit.MILLISECONDS.toSeconds(elapsedMillis);
				
				if ( ( elapsedSeconds ) >= lifeTime ) {
					bombIV.setBackgroundResource(0); //clear animation from imageView
					Bitmap bomb = BitmapFactory.decodeResource(context.getResources(), R.drawable.after);
					bombIV.setImageBitmap(bomb);
					messageText.setText("Boom!");
					chronometer.stop();	    	  
				}
			}
		});	
	} 
	
	public void onClickHandler(View view) 
	{	        
		if ( view.getId() == R.id.stopButton )
		{
			answer = Integer.parseInt(answerET.getText().toString());
			if ( answer == (number1 + number2) ) {
				chronometer.stop();
				animation.stop();
				String externalType = "nfclab.com:panicBomb";
				NdefRecord extRecord1 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], Integer.toString(elapsedSeconds).getBytes());
				NdefRecord extRecord2 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], Integer.toString(lifeTime).getBytes());
				NdefMessage message = new NdefMessage(new NdefRecord[] { extRecord1, extRecord2});
				mNfcAdapter.setNdefPushMessage(message, this);
				Toast.makeText(this, "Touch another mobile to send the bomb", Toast.LENGTH_SHORT).show();
	    	}
			else 
			{
				displayQuestion();
				answerET.setText("");
				Toast.makeText(this, "Wrong answer!!! Please try again", Toast.LENGTH_SHORT).show();
			}
		}
	 } 
	
	 @Override
	 public void onWindowFocusChanged (boolean hasFocus) 
	 {
		 super.onWindowFocusChanged(hasFocus);
		 if ( hasFocus ) {
			 animation.start();
		 } else {
			 animation.stop();
		 }
	 }

	public void displayQuestion() {
		number1 = (new Random().nextInt(100))+1;
		number2 = (new Random().nextInt(100))+1;
		questionText.setText(Integer.toString(number1) + " + " + Integer.toString(number2) + " = " ); 
	}


	@Override
	protected void onDestroy() {        
	    super.onDestroy();
		chronometer.stop();
	}
	
	public int random() {
		//Bomb will not explode within the first 10 seconds.
		return (new Random().nextInt(maxlifeTime))+10;
    }
	
	@Override
    public void onResume() {
        super.onResume();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        setIntent(intent);
    }

    void processIntent(Intent intent) 
    {    
    	NdefMessage[] messages = getNdefMessages(getIntent());
    	for (int i=0; i<messages.length; i++) 
   	 	{
       	 for (int j=0; j<messages[0].getRecords().length; j++)
       	 {
       		 NdefRecord record = messages[i].getRecords()[j];
       		 if(j == 0)
       			elapsedSeconds=Integer.parseInt(new String(record.getPayload()));
       		 else if(j == 1)
       			 lifeTime=Integer.parseInt(new String(record.getPayload()));
       	 }
       	 
       }
    	elapsedMillis = (long) elapsedSeconds*1000;
    	chronometer.setBase(SystemClock.elapsedRealtime() - elapsedMillis);

   }

    NdefMessage[] getNdefMessages(Intent intent) 
    {   
        NdefMessage[] msgs = null;
    	 if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
    		 Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
	        if (rawMsgs != null) {
	            msgs = new NdefMessage[rawMsgs.length];
	            for (int i = 0; i < rawMsgs.length; i++) {
	                msgs[i] = (NdefMessage) rawMsgs[i];
	            }
	        } else {
	            byte[] empty = new byte[] {};
	            NdefRecord record = new NdefRecord(NdefRecord.TNF_UNKNOWN, empty, empty, empty);
	            NdefMessage msg = new NdefMessage(new NdefRecord[] {
	                record
	            });
	            msgs = new NdefMessage[] {
	                msg
	            };
	        }
    	 } else {
    		  Log.d("NFC Panic Bomb", "Unknown intent.");
	            finish();
	        }     
        return msgs;
    } 
	
}
	