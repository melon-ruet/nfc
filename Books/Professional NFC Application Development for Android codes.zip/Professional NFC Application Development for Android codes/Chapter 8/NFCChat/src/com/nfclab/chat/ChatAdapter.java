package com.nfclab.chat;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
//import android.graphics.Bitmap;
//import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChatAdapter extends ArrayAdapter<String> {

	private TextView messageTV;
	private List<String> messagesAL = new ArrayList<String>();
	private LinearLayout lineLL;
    int size;

	@Override
	public void add(String message) {
		messagesAL.add(message);
	}

	public ChatAdapter(Context context, int textViewResourceId, int size) {
		super(context, textViewResourceId);
		this.size = size;
	}

	public int getCount() {
		return this.messagesAL.size();
	}
	
	public String getItem(int index) {
		return this.messagesAL.get(index);
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		if (row == null) {
			LayoutInflater inflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			row = inflater.inflate(R.layout.message, parent, false);
		}

		lineLL = (LinearLayout) row.findViewById(R.id.lineLL);

		String oneMessage = getItem(position);

		messageTV = (TextView) row.findViewById(R.id.messageTV);
		messageTV.setText(oneMessage.substring(0,oneMessage.length()-1));
			messageTV.setBackgroundResource(R.drawable.bubble_banana);
		
		if ( oneMessage.charAt(0) == '<')
			lineLL.setGravity(Gravity.LEFT);
		else 
			lineLL.setGravity(Gravity.RIGHT);				
		return row;
	}

}