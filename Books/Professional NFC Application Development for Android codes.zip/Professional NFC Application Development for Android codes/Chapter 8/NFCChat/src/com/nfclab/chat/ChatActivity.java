package com.nfclab.chat;

import java.nio.charset.Charset;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;


public class ChatActivity extends Activity implements CreateNdefMessageCallback, OnKeyListener {

	// parameters for saving messages as persistent data 
    String PREFERENCE_NAME = "NFCChat";
    SharedPreferences.Editor editor; 
	SharedPreferences settings;

	// parameters for NFC programming
	NfcAdapter mNfcAdapter;

	// parameters for holding the messages and displaying them
	ChatAdapter adapter;
	String messageList = "<:-))";
	String messageToSend = "";
    String messageToGet = "";
    ListView messagesLV;
    EditText messageToSendET;
    int size = 50; //Maximum size of a message

    @Override
	public void onCreate(Bundle savedInstanceState) {
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		adapter = new ChatAdapter(getApplicationContext(), R.layout.message, size);

		messagesLV = (ListView) findViewById(R.id.messagesLV);
		messagesLV.setAdapter(adapter);
		messageToSendET = (EditText) findViewById(R.id.messageToSendET);				
        messageToSendET.setOnKeyListener(this);
       
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter == null) {
        	Toast.makeText(this, "No available NFC adapter" , Toast.LENGTH_LONG).show();
            return;
        } 
        mNfcAdapter.setNdefPushMessageCallback(this, this);

        settings = getSharedPreferences(PREFERENCE_NAME, MODE_PRIVATE);
        
        messageList = settings.getString("messageList", "");

        // Parse messageList
        String thisMessage;
        char token;
        int start = 0;
        int end;
        while ( messageList.length() > 0 ) {
        	token = messageList.substring(start, start+1).charAt(0);
        	end = messageList.substring(start+1).indexOf(token) + 1;
        	thisMessage = messageList.substring(start, end+1);
        	adapter.add(thisMessage);
        	start = end + 1;  	

    		if ( messageList.substring(start) != null )
        		messageList = messageList.substring(start);
        	else
        		messageList = "";

    		start = 0;
        } 
	} 
    
    protected void saveMessages() {
		messageList = "";
		for ( int i = 0; i < adapter.getCount(); i++) {
			messageList += adapter.getItem(i);
		}
		editor = settings.edit();			
		editor.putString("messageList", messageList);
		editor.commit();
    }    

    public void get(String messageToGet) { 

    	  	for ( int i = 0; i < adapter.getCount(); i++) {
        	  	messageList += adapter.getItem(i);
    	  	}

		adapter.add('<' + messageToGet + '<'); 
    	messageList = "";
		if ( !adapter.isEmpty() ) { 
    	  	for ( int i = 0; i < adapter.getCount(); i++) {
        	  	messageList += adapter.getItem(i);
    	  	}
    	}
        saveMessages();
    }
 	       
    public boolean onKey(View v, int keyCode, KeyEvent event) {
		// If the event is a key-down event on the "enter" button
		if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {		
			if( messageToSendET.getText().length() > 0 ) 
			{
				messageToSend = messageToSendET.getText().toString();
		    	adapter.add('>' + messageToSend + '>');  
				saveMessages();
				messageToSendET.setText(""); 
				Toast.makeText(this, "Touch another mobile to share the chat message", Toast.LENGTH_LONG).show();
			}
			return true;
		}
		return false;
	}
    
 	@Override
    public NdefMessage createNdefMessage(NfcEvent event) {    	
 		NdefMessage message = create_MIME_NdefMessage("application/nfcchat", messageToSend);
 		messageToSend = "";
 		return message; 		
    }
 	
 	public NdefMessage create_MIME_NdefMessage(String mimeType, String payload) {
    	NdefRecord mimeRecord = new NdefRecord(NdefRecord.TNF_MIME_MEDIA ,
    									mimeType.getBytes(), new byte[0], 
    									payload.getBytes(Charset.forName("US-ASCII")));
        NdefMessage message = new NdefMessage(new NdefRecord[] { mimeRecord});
        return message;
 	}
   
 	@Override
    public void onResume() {
 		super.onResume();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        setIntent(intent);
    }

    void processIntent(Intent intent) {
    	NdefMessage[] messages = getNdefMessages(getIntent());
    	 
    	for ( int i = 0; i < messages.length; i++ ) {
    		for( int j = 0; j < messages[0].getRecords().length; j++ ) {
    			NdefRecord record = messages[i].getRecords()[j];
    			String payload = new String(record.getPayload());
    			get( payload );
    		}        	 
    	} 
    }

    NdefMessage[] getNdefMessages(Intent intent) 
    {
        NdefMessage[] msgs = null;
        if ( NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction()) ) {
        	Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
	        if ( rawMsgs != null) {
	        	msgs = new NdefMessage[rawMsgs.length];
	            for ( int i = 0; i < rawMsgs.length; i++ ) {
	            	msgs[i] = (NdefMessage) rawMsgs[i];
	            }
	        } else {
	        	byte[] empty = new byte[] {};
	            NdefRecord record = new NdefRecord(NdefRecord.TNF_UNKNOWN, empty, empty, empty);
	            NdefMessage msg = new NdefMessage(new NdefRecord[] 
	            { 
	            	record 
	           	});
	            msgs = new NdefMessage[] {
	                msg
	            };
	        }
    	} else {
    		 Log.d ( "NFC Chat", "Unknown intent." );
	            finish();
    	}
        return msgs;
    }	
}