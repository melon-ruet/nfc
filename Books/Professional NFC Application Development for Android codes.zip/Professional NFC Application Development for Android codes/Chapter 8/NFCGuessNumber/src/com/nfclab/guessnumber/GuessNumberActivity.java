package com.nfclab.guessnumber;

import java.util.Random;

import android.app.Activity;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcEvent;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class GuessNumberActivity extends Activity implements CreateNdefMessageCallback {
	NfcAdapter mNfcAdapter;
	private String previous = "";
	private int high = 100;
	private int low = 1;
	private int target = 0;
	private int guess = 0;
	private boolean found = false;
	
	private EditText previousET;
	private EditText highET;
	private EditText lowET;
	private EditText guessET;
	private TextView resultTV ;
	private  Button guessButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);      

        previousET = ((EditText) findViewById(R.id.previousET));
        highET = ((EditText) findViewById(R.id.highET));
        lowET = ((EditText) findViewById(R.id.lowET));
        guessET = (EditText) findViewById(R.id.guessET);
        resultTV = (TextView) findViewById(R.id.resultTV);
         guessButton = (Button)this.findViewById(R.id.guessButton);
        
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter == null) {
        	resultTV.setText("NFC apdater  is not available");
            finish();
            return;
        } 
        
        mNfcAdapter.setNdefPushMessageCallback(this, this);
        
        if ( target == 0 ) {
        	target = random();
        }

        display(true);
 
    }
    
    public void onClickHandler(View view) {
        
    	if(view.getId() == R.id.guessButton){
    		guess = Integer.parseInt(guessET.getText().toString());
    		previous = previous + " " + guessET.getText();
    		if ( guess == target ) {
    			low = guess;
    			high = guess;
    			found=true;
    			resultTV.setText("SUCCESS. You find the secret number: "+guess);
    		}
    		else {
    			if ( guess < target ) {
    				low = guess + 1;
        			resultTV.setText("Your guess is LOW");
    			}
    			else {
    				high = guess - 1;
        			resultTV.setText("Your guess is HIGH");
    			}
    		}
    		display(false);
	       Toast.makeText(this, "Touch another mobile to continue playing", Toast.LENGTH_SHORT).show();
		}
    }
    
    public int random() {
    	return (new Random().nextInt(100))+1;
    }
    
    public void display(boolean focus) {
    	previousET.setText(previous);
    	highET.setText(""+high);
    	lowET.setText(""+low);
    	guessET.setText("");
		guessET.setFocusable(focus);
    }
    
    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {
 
        String externalType = "nfclab.com:guessNumber";
 		NdefRecord extRecord1 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], previous.getBytes());
 		NdefRecord extRecord2 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], Integer.toString(high).getBytes());
 		NdefRecord extRecord3 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], Integer.toString(low).getBytes());
 		NdefRecord extRecord4 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], Integer.toString(target).getBytes());
 		NdefRecord extRecord5 = new NdefRecord(NdefRecord.TNF_EXTERNAL_TYPE, externalType.getBytes(), new byte[0], new Boolean(found).toString().getBytes());
        NdefMessage message = new NdefMessage(new NdefRecord[] { extRecord1, extRecord2, extRecord3, extRecord4,extRecord5});
        return message;
    }
    
    @Override
    public void onResume() {
        super.onResume();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        setIntent(intent);
    }

    void processIntent(Intent intent) {
        
    	 NdefMessage[] messages = getNdefMessages(getIntent());
    	 
    	 for(int i=0;i<messages.length;i++){
        	 for(int j=0;j<messages[0].getRecords().length;j++){
        		 NdefRecord record = messages[i].getRecords()[j];
        		 if(j==0)
        			 previous=new String(record.getPayload());
        		 else if(j==1)
        			 high=Integer.parseInt(new String(record.getPayload()));
        		 else if(j==2)
        			 low=Integer.parseInt(new String(record.getPayload()));
        		 else if(j==3)
        			 target=Integer.parseInt(new String(record.getPayload()));
        		 else if(j==4)
        			 found=Boolean.parseBoolean(new String(record.getPayload()));
        	 }
        	 
        }
    	 display(true);
    	 if(found==true){
 			resultTV.setText("Your opponent already found the secret number!!! "+target);
 			guessET.setFocusable(false);
 		}

    }
    
 NdefMessage[] getNdefMessages(Intent intent) {
        
    	// Parse the intent
        NdefMessage[] msgs = null;
    	 if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
    		 Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
	        if (rawMsgs != null) {
	            msgs = new NdefMessage[rawMsgs.length];
	            for (int i = 0; i < rawMsgs.length; i++) {
	                msgs[i] = (NdefMessage) rawMsgs[i];
	            }
	        } else {
	            // Unknown tag type
	            byte[] empty = new byte[] {};
	            NdefRecord record = new NdefRecord(NdefRecord.TNF_UNKNOWN, empty, empty, empty);
	            NdefMessage msg = new NdefMessage(new NdefRecord[] {
	                record
	            });
	            msgs = new NdefMessage[] {
	                msg
	            };
	        }
    	 }else {
    		  Log.d("NFC Guess Number", "Unknown intent.");
	            finish();
	        }
         
        return msgs;
    }
    

}