package com.nfclab.nfcpostertagwriter;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NFCPosterWriterActivity extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);  


        Button writeUrlButton = (Button) findViewById(R.id.writeUrlButton);
        writeUrlButton.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent( view.getContext(), WriteUrlActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });
        
        Button writePhoneButton = (Button) findViewById(R.id.writePhoneButton);
        writePhoneButton.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent( view.getContext(), WritePhoneActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });        
        
        
        Button writeSmsButton = (Button) findViewById(R.id.writeSmsButton);
        writeSmsButton.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent( view.getContext(), WriteSmsActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });        
        
        
        Button writeMapButton = (Button) findViewById(R.id.writeMapButton);
        writeMapButton.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), WriteMapActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });        

        Button writeMailButton = (Button) findViewById(R.id.writeMailButton);
        writeMailButton.setOnClickListener(new View.OnClickListener() 
        {
           public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), WriteMailActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });        

        Button quitButton	= (Button)this.findViewById(R.id.quitButton);
        quitButton.setOnClickListener(new android.view.View.OnClickListener() 
        {
        	public void onClick(View v) {
        		finish();
        	}
        });        
        
        
    }
}