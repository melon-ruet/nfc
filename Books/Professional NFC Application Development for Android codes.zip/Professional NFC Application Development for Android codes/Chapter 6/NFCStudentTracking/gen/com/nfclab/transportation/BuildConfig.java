/** Automatically generated file. DO NOT MODIFY */
package com.nfclab.transportation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}