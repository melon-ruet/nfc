package com.nfclab.peertopeer4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.ContactsContract.Contacts;
import android.provider.Settings;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.widget.Button;

public class PeertoPeer4 extends Activity {
  
	NfcAdapter mNfcAdapter;
	private TextView messageText;
    public Button sendButton;
	private final int PICK_CONTACT = 1;
	private byte[] bytesToSend;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        messageText = (TextView)findViewById(R.id.messageText);
        messageText.setText( "Select a contact to share");        	

        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter == null) {
            finish();
            return;
        } 
        
        sendButton = (Button) findViewById(R.id.selectButton);
		sendButton.setOnClickListener(new OnClickListener()
		{ 
			public void onClick(View v) {
				Intent intent = new Intent(Intent.ACTION_PICK);
		        intent.setType(ContactsContract.Contacts.CONTENT_TYPE);
		        startActivityForResult(intent, PICK_CONTACT);
			}
		}); 
	    
	}
	
 	public void onActivityResult(int reqCode, int resultCode, Intent data) {
 		super.onActivityResult(reqCode, resultCode, data);
 		String contactInfo = "";
 		switch (reqCode) 
 		{
 			case (PICK_CONTACT):
 			{ 				
 				if (resultCode == Activity.RESULT_OK) {

 					Uri contactData = data.getData();
 					Cursor people =  getContentResolver().query(contactData, null, null, null, null);

 					if ( people.moveToFirst() ) {
 						
 						 try {
 					            String lookupKey = people.getString(people.getColumnIndex(Contacts.LOOKUP_KEY));


 					            Uri uri = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_VCARD_URI,
 					                    lookupKey);
 					            AssetFileDescriptor afd;
 					            try {
 					                afd = getContentResolver().openAssetFileDescriptor(uri, "r");
 					                FileInputStream fis = afd.createInputStream();
 					               bytesToSend = new byte[(int) afd.getDeclaredLength()];
 					                fis.read(bytesToSend);
 					               contactInfo = new String(bytesToSend);
 					            } catch (FileNotFoundException e) {
 					                e.printStackTrace();
 					            } catch (IOException e) {
 					                e.printStackTrace();
 					            }
 					    } finally {
 					        people.close();
 					    }	
 						
 						 NdefMessage message= create_MIME_NdefMessage("text/x-vcard", bytesToSend);
 						 mNfcAdapter.setNdefPushMessage(message, this);
 						messageText.setText(contactInfo);
 						 Toast.makeText(this, "Touch another mobile to share the contact", Toast.LENGTH_SHORT).show();
 						
 
 	 				} 
 				
 				}
 			} 
 		} 
 	} 	

 	    public NdefMessage create_MIME_NdefMessage(String mimeType, byte[] payload) {
 	    	NdefRecord mimeRecord = new NdefRecord(NdefRecord.TNF_MIME_MEDIA ,
 					mimeType.getBytes(), new byte[0], 
 				    payload);
 	        NdefMessage message= new NdefMessage(new NdefRecord[] { mimeRecord
 	        });
 	        
 		    return message;
 		}
 	    
 	    @Override
 	    public void onResume() {
 	        super.onResume();
 	       if (!mNfcAdapter.isEnabled()) {
 	          startActivity(new Intent(Settings.ACTION_NFC_SETTINGS));
 	 } else if (!mNfcAdapter.isNdefPushEnabled()) {
 	          startActivity(new Intent(Settings.ACTION_NFCSHARING_SETTINGS));
 	 }
  
 	    }

} 