package com.nfclab.peertopeer1;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.nfc.NfcEvent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.nio.charset.Charset;



public class PeertoPeer1 extends Activity implements CreateNdefMessageCallback {
    NfcAdapter mNfcAdapter;
    private TextView messageText;
    private String payload="";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        messageText = (TextView) this.findViewById(R.id.messageText);
        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter == null) {
            messageText.setText("NFC apdater  is not available");
            finish();
            return;
        } 
        messageText.setText("Touch another mobile to beam 'nfclab.com'!!!");

        mNfcAdapter.setNdefPushMessageCallback(this, this);
    }

    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {

    	byte[] uriField = "nfclab.com".getBytes(Charset.forName("US-ASCII"));
         byte[] payload = new byte[uriField.length + 1];            
         payload[0] = 0x01;                               
         System.arraycopy(uriField, 0, payload, 1, uriField.length);  
         NdefRecord URIRecord  = new NdefRecord(
             NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_URI, new byte[0], payload);
         NdefMessage message= new NdefMessage(new NdefRecord[] { URIRecord });
        return message;
    }
   
    @Override
    public void onResume() {
        super.onResume();
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        setIntent(intent);
    }

    void processIntent(Intent intent) {
        
    	 NdefMessage[] messages = getNdefMessages(getIntent());
    	 
    	 for(int i=0;i<messages.length;i++){
        	 for(int j=0;j<messages[0].getRecords().length;j++){
        		 NdefRecord record = messages[i].getRecords()[j];
        		 payload=new String(record.getPayload(),1,record.getPayload().length-1,Charset.forName("UTF-8"));
        		messageText.setText( payload );
        	 }
        	 
        }
 

    	 LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
    	            LinearLayout.LayoutParams.WRAP_CONTENT,
    	            LinearLayout.LayoutParams.WRAP_CONTENT);
    	    Button button = new Button(this);
    	    this.addContentView(button, params);
    	    messageText.setText("");
    	    button.setText("Open Link: "+ payload );
    	    button.setOnClickListener(new View.OnClickListener() {
    	        public void onClick(View view) {
    	        	Intent data = new Intent();
       			 data.setAction(Intent.ACTION_VIEW);
       			 data.setData(Uri.parse("http://www."+payload));
       			try {
       	    		startActivity(data); 
       	    	} catch (ActivityNotFoundException e) {
       	    		return;
       	    	}
    	        }
    	    });
    }
    
 NdefMessage[] getNdefMessages(Intent intent) {
        
        NdefMessage[] msgs = null;
    	 if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(intent.getAction())) {
    		 Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
	        if (rawMsgs != null) {
	            msgs = new NdefMessage[rawMsgs.length];
	            for (int i = 0; i < rawMsgs.length; i++) {
	                msgs[i] = (NdefMessage) rawMsgs[i];
	            }
	        } else {
	            byte[] empty = new byte[] {};
	            NdefRecord record = new NdefRecord(NdefRecord.TNF_UNKNOWN, empty, empty, empty);
	            NdefMessage msg = new NdefMessage(new NdefRecord[] {
	                record
	            });
	            msgs = new NdefMessage[] {
	                msg
	            };
	        }
    	 }else {
    		  Log.d("PeertoPeer1 ", "Unknown intent.");
	            finish();
	        }
         
        return msgs;
    }
}